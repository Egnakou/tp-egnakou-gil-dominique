public class Specialisation{
    private boolean CarteValide;
    private boolean CodeCorrect;


    public Specialisation(boolean CarteValide,boolean CodeCorrect){
        this.CarteValide= CarteValide;
        this.CodeCorrect=CodeCorrect;
    }
    public static boolean AccesAutoriser(boolean CarteValide,boolean CodeCorrect){
        if(CarteValide==true && CodeCorrect==true){
            return true;
        }
        else {
            return false;
        }

    }

    public boolean isCarteValide() {
        return CarteValide;
    }

    public boolean isCodeCorrect() {
        return CodeCorrect;
    }
}
