import java.util.Scanner;
public class Main {
    private static final int Carte = 121063;
    private static final int Code =300912;
   static Scanner scanner=new Scanner(System.in);


    public static void main(String[] args){
        System.out.println("Entre ton numero de carte:");
        int NumeroDeCarte= scanner.nextInt();
        System.out.println("Entrez votre code secret:");
        int CodeSecret= scanner.nextInt();
        boolean CarteCorrect;
        if(Carte ==NumeroDeCarte){
            CarteCorrect=true;
        }
        else{
            CarteCorrect=false;
        }

        boolean CodeCorrecte;
        if (Code ==CodeSecret){
            CodeCorrecte=true;
        }
        else{
            CodeCorrecte=false;
        }
        Specialisation SP=new Specialisation(CarteCorrect,CodeCorrecte);
        Modelisation MOD=new Modelisation();
        MOD.VerificationDecarte(SP.isCarteValide());
        MOD.VerificationDeCode(SP.isCodeCorrect());

        if(Carte==NumeroDeCarte && Code==CodeSecret){
            MOD.setActuel(Modelisation.Etat.Acces_Accorder);
            System.out.println("Acces accorder");

        }else{
            MOD.setActuel(Modelisation.Etat.Acces_Refuser);


        }
        int compteur=0;
        while (MOD.getActuel()== Modelisation.Etat.Acces_Refuser&&compteur<3){
            if (NumeroDeCarte==Carte&&CodeSecret==Code){
                System.out.println("Acces accorde");
                MOD.setActuel(Modelisation.Etat.Acces_Accorder);
            }
            else {
                System.out.println("Acces refuse");
                System.out.println("Il vous reste " + (3-compteur) + " tentatives");
                compteur++;
                System.out.println("Entre a nouveau tom numero :");
                NumeroDeCarte = scanner.nextInt();
                System.out.println("Entre a nouveau ton code secret : ");
                CodeSecret = scanner.nextInt();

                if (NumeroDeCarte==Carte&&CodeSecret==Code){
                    System.out.println("Acces accorde");
                    MOD.setActuel(Modelisation.Etat.Acces_Accorder);
                }
            }
            if (compteur==3){
                System.out.println("acces bloque");
                MOD.Alarme();
            }

        }



    }

}

