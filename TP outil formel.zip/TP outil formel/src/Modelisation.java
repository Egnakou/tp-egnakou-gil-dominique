public class Modelisation {
    private Etat actuel;
    enum Etat {
        commencer,
        Carte_Valide,
        Code_Correct,
        Acces_Accorder,
        Acces_Refuser,

    }

    public Modelisation() {
        this.actuel = Etat.commencer;
    }
    public void VerificationDecarte(boolean Carte){
        if(Carte){
        this.actuel = Etat.Carte_Valide;

    }else{
            this.actuel = Etat.Acces_Refuser;


        }
        }

    public void VerificationDeCode(boolean code){
        if(this.actuel==Etat.Carte_Valide){
            if(code = true){
                this.actuel=Etat.Acces_Accorder;
                System.out.println("Acces accorder");

            }else{
                this.actuel=Etat.Acces_Refuser;

            }
        }
    }
    public void Alarme(){
        System.out.println("Alarme declancher");
    }

    public Etat getActuel() {
        return actuel;
    }

    public void setActuel(Etat actuel) {
        this.actuel = actuel;
    }
}
